# Roll: 1907083
# Name: Nushrat Tarmin Meem

import matplotlib.pyplot as plt   #plotting
import pandas as pd   #data manipulation
from PIL import Image   #image processing
import re   #regular expressions
import autograd.numpy as np   #autograd functionality
from autograd import grad
import glob   #file handling

#function to calculate the regression line
def regression_function(a, b, x):
    return a * x + b

#function to calculate the loss (mean squared error)
def loss_function(a, b, x, y):
    return np.square(y - a * x - b)

#file path for data
path = r"E:\2) ML Lab\1907083_GradientDescent\data.xlsx"
data = pd.read_excel(path)
x_values = data.x
y_values = data.y

#plotting the initial data points
plt.scatter(data.x, data.y, color='blue', marker='o')

#directory for saving intermediate images
image_directory = "curve_images/"
output = "resulting_animation.gif"
f_in = "curve_images/*.png"

#initial values for slope, intercept, and learning rate
slope_m = 1.2
intercept_c = 0.05
learning_rate = 0.002

#calculating the gradient of the loss function w.r.t slope (m) and intercept (c)
jslope_dm = grad(loss_function, 0)
jintercept_dc = grad(loss_function, 1)

i = 0
while i < 1000:
    j = 0
    error_cal = 0

    #calculating total error for all data points    
    while j < len(x_values):
        p, q = x_values[j], y_values[j]
        error_cal += loss_function(slope_m, intercept_c, p, q)
        j += 1    
    jslope_dm_sum = 0
    jintercept_dc_sum = 0
    j = 0
    
    #calculating the sum of gradients w.r.t slope and intercept
    while j < len(x_values):
        p, q = x_values[j], y_values[j]
        jslope_dm_sum += jslope_dm(slope_m, intercept_c, p, q)
        jintercept_dc_sum += jintercept_dc(slope_m, intercept_c, p, q)
        j += 1
    
    #updating slope (m) and intercept (c) using gradient descent
    slope_m -= learning_rate * jslope_dm_sum
    intercept_c -= learning_rate * jintercept_dc_sum
    
    #checking if the current iteration is a multiple of 10 or not
    #plotting and saving images every 10 iterations
    if i % 10 == 0:
        st=[]
        j = 0
        
        while j < len(x_values):
            st_val = regression_function(slope_m, intercept_c, x_values[j])
            st.append(st_val)
            j += 1
      
        plt.scatter(data.x, data.y, color='blue', marker='o')
        plt.plot(x_values, st, color="red")   
        plt.xlabel('x_values')
        plt.ylabel('y_values')
        plt.title(f"Iteration No: {int(i)}")
        plt.savefig(f"{image_directory}image_no_{int(i/10+1)}.png", dpi=500)
        plt.show()      
        st.clear()
    i += 1

#custom sorting function to sort filenames naturally
naturally_sorted = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split('(\d+)', s)]

#loading and saving images into gif
img, *imgs = [Image.open(f) for f in sorted(glob.glob(f_in), key=naturally_sorted)]
img.save(fp=output, format='GIF', append_images=imgs, save_all=True, duration=500, loop=0)
