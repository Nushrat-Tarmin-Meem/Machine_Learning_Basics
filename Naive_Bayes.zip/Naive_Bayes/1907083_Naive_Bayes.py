# -*- coding: utf-8 -*-
"""
Created on Wed May 15 02:06:29 2024

@author: meemc
"""
# Importing necessary libraries
import pandas as pd

# Reading the data from Excel file
data = pd.read_excel("naive_bayes_data.xlsx")

# Extracting unique classes from the 'class' column
unique_classes = data["class"].unique()

# Calculating the count of each class
class_counts = data["class"].value_counts()

# Calculating the total number of data points
total_data_points = len(data)

# Calculating the prior probability of each class
class_probabilities = {class_name: count / total_data_points for class_name, count in class_counts.items()}

# Extracting unique words from the dataset
unique_words = set()
index = 0
while index < len(data['words']):
    sentence = data['words'][index]
    unique_words.update(sentence.split())
    index += 1

# Calculating the total number of unique words
total_unique_words = len(unique_words)

# Creating dictionaries to store words for each class and their counts
words_per_class = {}
word_counts_per_class = {}
class_index = 0
while class_index < len(unique_classes):
    class_name = unique_classes[class_index]
    class_text = " ".join(data[data["class"] == class_name]["words"])
    words_per_class[class_name] = class_text.split()
    word_counts_per_class[class_name] = len(words_per_class[class_name])
    class_index += 1

# Calculating the conditional probabilities of each word for each class using Laplace smoothing
word_probabilities = {}
unique_words_list = list(unique_words)
word_index = 0
while word_index < len(unique_words_list):
    word = unique_words_list[word_index]
    word_probabilities[word] = {}
    class_index = 0
    while class_index < len(unique_classes):
        class_name = unique_classes[class_index]
        word_probabilities[word][class_name] = (words_per_class[class_name].count(word) + 1) / (word_counts_per_class[class_name] + total_unique_words)
        class_index += 1
    word_index += 1

# The user to enter a sentence for classification
input_sentence = input("Enter Sentence: ")
words_in_sentence = input_sentence.split()

# Initializing a dictionary to store the calculated probabilities for each class
calculated_probabilities = {}
total_data_points = sum(data['class'].value_counts().values)

# Calculating the initial probabilities for each class
calc_prob_index = 0
while calc_prob_index < len(unique_classes):
    class_name = unique_classes[calc_prob_index]
    calculated_probabilities[class_name] = data["class"].value_counts().get(class_name, 0) / total_data_points
    calc_prob_index += 1

# Calculating the probabilities for each word in the input sentence
word_index = 0
while word_index < len(words_in_sentence):
    word = words_in_sentence[word_index]
    if word in word_probabilities:
        class_index = 0
        while class_index < len(unique_classes):
            class_name = unique_classes[class_index]
            calculated_probabilities[class_name] *= word_probabilities[word].get(class_name, 1)
            class_index += 1
    word_index += 1

# Finding the class with the maximum probability
max_probability_class = max(calculated_probabilities, key=calculated_probabilities.get)
print("Matched Class:", max_probability_class)
